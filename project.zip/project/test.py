# flask is a popular lightweight web framework for python
# key features of flask 
# 1)Minimalist
# 2)Extensibility
# 3)Routing
# 4)Template engine
# 5)Development server
# 6)lightweight

# setting up flask
from flask import *
# initialize the app
app=Flask(__name__)

# Define the routes
@app.route("/api/home")
def home():
    return jsonify({ "message":"welcome home" })

@app.route("/api/services")
def services():
    return "welcome to services"

@app.route("/api/about")
def about():
    return "welcome to about"

# posting variables request to api and get response
@app.route("/api/calc")
def calc():
    number1=request.form["number1"]
    number2=request.form["number2"]
    sum=int(number1)+int(number2)
    return jsonify({ "answer":sum })


# this' the last code
# run the application
app.run(debug=True)
