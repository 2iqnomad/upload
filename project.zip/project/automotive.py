from flask import Flask, request, jsonify
import pymysql
import os
import pymysql.cursors
import requests
import datetime
import base64
from requests.auth import HTTPBasicAuth
# from flask_cors import CORS

app = Flask(__name__)
# CORS(app)

app.config['UPLOAD_FOLDER'] = '/home/goodguy/AUTOMOTIVE'

# Database connection function
connection=pymysql.connect(host='goodguy.mysql.pythonanywhere-services.com',user='goodguy',password='USER1234',database='goodguy$default')

cursorclass=pymysql.cursors.DictCursor
    

# Customer Signup
@app.route("/api/signup", methods=["POST"])
def signup():
    name = request.form["name"]
    email = request.form["email"]
    phone = request.form["phone"]
    address = request.form["address"]
    customer_photo = request.files["customer_photo"]

    # Save customer photo
    filename = customer_photo.filename
    photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    customer_photo.save(photo_path)

    connection =pymysql.connect(host='goodguy.mysql.pythonanywhere-services.com',user='goodguy',password='USER1234',database='goodguy$default')

    cursor = connection.cursor()

    sql = "INSERT INTO customers (name, email, phone, address, customer_photo) VALUES (%s, %s, %s, %s, %s)"
    cursor.execute(sql, (name, email, phone, address, filename))
    connection.commit()

    return jsonify({"message": "Signup successful"})

# Customer Signin
@app.route("/api/signin", methods=["POST"])
def signin():
    email = request.form["email"]
    phone = request.form["phone"]

    connection =pymysql.connect(host='goodguy.mysql.pythonanywhere-services.com',user='goodguy',password='USER1234',database='goodguy$default')

    cursor = connection.cursor()

    sql = "SELECT * FROM customers WHERE email = %s AND phone = %s"
    cursor.execute(sql, (email, phone))

    user = cursor.fetchone()
    if user:
        return jsonify({"message": "Login successful", "user": user})
    else:
        return jsonify({"message": "Login failed"})

# Add Automotive Products
@app.route("/api/add_automotive", methods=["POST"])
def add_automotive():
    name = request.form["name"]
    brand = request.form["brand"]
    compatibility = request.form["compatibility"]
    price = request.form["price"]
    stock_quantity = request.form["stock_quantity"]
    warranty_period = request.form["warranty_period"]
    automotive_photo = request.files["automotive_photo"]

    # Save product photo
    filename = automotive_photo.filename
    photo_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    automotive_photo.save(photo_path)

    connection =pymysql.connect(host='goodguy.mysql.pythonanywhere-services.com',user='goodguy',password='USER1234',database='goodguy$default')

    cursor = connection.cursor()

    sql = """INSERT INTO automotive 
             (name, brand, compatibility, price, stock_quantity, warranty_period, automotive_photo) 
             VALUES (%s, %s, %s, %s, %s, %s, %s)"""
    cursor.execute(sql, (name, brand, compatibility, price, stock_quantity, warranty_period, filename))
    connection.commit()

    return jsonify({"message": "Automotive product added successfully"})

# Get Automotive Products
@app.route("/api/get_automotive", methods=["GET"])
def get_automotive():
    connection =pymysql.connect(host='goodguy.mysql.pythonanywhere-services.com',user='goodguy',password='USER1234',database='goodguy$default')

    cursor = connection.cursor()

    sql = "SELECT * FROM automotive"
    cursor.execute(sql)

    products = cursor.fetchall()
    return jsonify(products)

# Mpesa Payment Route
@app.route('/api/mpesa_payment', methods=['POST'])
def mpesa_payment():
    if request.method == 'POST':
        amount = request.form['amount']
        phone = request.form['phone']

        consumer_key = "GTWADFxIpUfDoNikNGqq1C3023evM6UH"
        consumer_secret = "amFbAoUByPV2rM5A"

        api_URL = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials"
        response = requests.get(api_URL, auth=HTTPBasicAuth(consumer_key, consumer_secret))
        data = response.json()
        access_token = "Bearer " + data['access_token']

        timestamp = datetime.datetime.today().strftime('%Y%m%d%H%M%S')
        passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919'
        business_short_code = "174379"

        data_str = business_short_code + passkey + timestamp
        encoded = base64.b64encode(data_str.encode())
        password = encoded.decode()

        payload = {
            "BusinessShortCode": "174379",
            "Password": password,
            "Timestamp": timestamp,
            "TransactionType": "CustomerPayBillOnline",
            "Amount": amount,
            "PartyA": phone,
            "PartyB": "174379",
            "PhoneNumber": phone,
            "CallBackURL": "https://yourwebsite.com/api/confirm_payment",
            "AccountReference": "Automotive Store",
            "TransactionDesc": "Payment for automotive products"
        }

        headers = {
            "Authorization": access_token,
            "Content-Type": "application/json"
        }

        url = "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest"
        response = requests.post(url, json=payload, headers=headers)

        return jsonify({"message": "An MPESA prompt has been sent to your phone. Please check and complete payment."})

# Run the application
if __name__ == "__main__":
    app.run(debug=True)