// asume you have the following distancetable
// distancetable:
// distance                  amount to pay
// 0-100                      pay 5 USD
// 101-500                    Pay10 USD
// 501-1000                   PAY 20 USD
// 1001 and above             pay 40 USD

let distance=877
if(distance<=0){
    console.log("pay 5 USD")
}
else if (distance=101 && distance<=500){
    console.log("pay 10 USD")
}
else if (distance>501 && distance<=1000){
    console.log("pay 20 USD")
}
 else if (distance>1001 ){
        console.log("pay 40 USD")
}
else{
    console.log("invalid distance")
}