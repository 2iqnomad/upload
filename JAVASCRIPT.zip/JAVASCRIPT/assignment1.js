// create 3 string variables to store username , password and email and log them in the console
let username = "isaac"
console.log(username)

let password="13154"
console.log(password)

let email= "isaac@gmail.com"
console.log(email)

// create an array of  counties and log county at index 2
let counties=["Kenya","Tanzania","Somalia","Egypt","Madagascar"]
console.log(counties[2])

// log county at index 4
console.log(counties[4])