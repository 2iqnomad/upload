// javascript while loop
// a java script  while loop is  a control flow statement that runs a block of code for as long as a specified condition is true

let i=0 
while (i<=5){
    console.log(i)
    i++}

let n=0
while (n<20){
    console.log(n)
    n+=2
}

let m=10
while (m>=1){
    console.log(m)
    m-=1
}