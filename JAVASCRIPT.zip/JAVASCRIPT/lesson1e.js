// non primitive datatypes 
// we have three objects, arrays, functions 
// object
// in python we refferd them as dictionaries and in java script we call them objects
// NB: we have key values pairs
let person = {
    name:"Alice",
    age : 20,
    isAdmin : true

}
console.log(person)
// output person name
console.log(person.name)

// output person age
console.log(person.age) 

// out person isAdmin
console.log(person.isAdmin)

// Arrays
// in python we reffered them as liosts but in javascript we cal them arrays
 
// an array is an ordered collection of items
let fruits = ["apple", "banana","cherry"]

// output
console.log(fruits)

// output fruits at index 1
console.log(fruits[1])

// output fruit at index 0
console.log(fruits[0])