//   functions with parameters 
// a function with a parameter is a function that accepts values or arguements when they are called
// the difference btwn a parameter and an arguement
// example1
function greeting(name){
    console.log("hello " + name )
}
greeting("josh")
greeting("bob")
greeting("smith")
greeting("Johnson")
greeting("Mike")

function county(county){
    console.log("My county is " + county )
}
county('marsabit')
county('Nakuru')
county('Wajir')

// Function to add 2 numbers
function sum(num1 , num2 ){
let  ans=num1+num2
console.log("The sum is " +ans)
}
sum(100,57)
sum(120,150)

// function to subtract two numbers
function subtract(num1,num2){
    let ans=num1-num2
    console.log("The subtraction is "+ ans)
}
subtract(100,57)

// function to divide two numbers
function divide(num1,num2){
    let ans=num1/num2
    console.log("The division is "+ ans)
}
divide(100,50)

// function to multiply two numbers
function multiply(num1,num2){
    let ans=num1*num2
    console.log("The multiplication is "+ ans)
}
multiply(10,57)


