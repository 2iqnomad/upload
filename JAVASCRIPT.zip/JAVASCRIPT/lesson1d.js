// javascript data types
// a data type are that defines the type of values stored variables
// we have the following data types
// 1.number-a number are numeric values ,,1,3,4
// 2.string-a string is a source of characters "hello world","goodmorning",     "goodafternoon"
// 3.boolean- boolean defines true of false value,,5>2 true,
// 4.symbol-represents s unique and imutablevalue main
// 5.null-
// we have primitive  data typs which include string, null, number,boolean, undefined
// String
// we can use double quotes or single quotes
let username = "Alice"
console.log(username)

let greeting ='hello world'
console.log(greeting)

// java script numbers
// we have integer and float
// interger is a whole number
let age =25
console.log(age)
// float
// a number with a decimal
let pi =3.142
console.log(pi)

//boolean
// it can eitherbe trueor false
let isAdult=true
console.log(isAdult)

let isRegister = false
console.log(isRegister)

//undefined
let somevariable
console.log(somevariable)

// null
let user = null
console.log(user)