// using cost declare variables using const to store height, temperature, points
const height = 90
console.log(height)

const temperature = 34
console.log(65)

const points = 23
console.log(78)