let marks=59
if(marks<30){console.log("fail!")}
else if(marks>=30 && marks<50){console.log("Bellow average")}
else if(marks>=50 && marks<70){console.log("above average")}
else if(marks>=70 && marks<100){console.log("Excelent")}
else if(marks<=0 && marks<100){console.log("invalid mark!")}