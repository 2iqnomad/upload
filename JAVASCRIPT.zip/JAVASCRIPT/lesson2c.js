// if else if else statement a condition statement that is used in the execution of a computer program in pre-defined rules
let age=25
if(age<14){
    console.log("youre to young to watch this movie")
}
else if (age>=14 && age<18){
    console.log("you can watch this movie with parental guidance")
}
else if (age>18 && age<=40){
    console.log("you can watch this movie")
}
else{
    console.log("this movie is for young people")
}