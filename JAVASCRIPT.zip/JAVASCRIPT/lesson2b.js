// if else statements are control flow thats allows  youb to execute blocks ofcodewether true or false
let age=10
if (age<13){
    console.log("youre to young to watch this movie")
}
else{
    console.log("you can watch this movie")
}