// using if else statement check if one is elligible to vote
let age=18
if (age<17){
    console.log("youre not elligble to vote")
}

else{
    console.log("youre elligble to vote")
    }



// come up with a program if one can vie for president
let age1=18
if (age<=35){
    console.log("youre not elligble to vie for president")
}

else{
    console.log("youre elligble to vie for president")
    }

