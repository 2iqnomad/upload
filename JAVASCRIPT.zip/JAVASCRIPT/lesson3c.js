// A JavaScript function is a block of code designed to perform a particular task.
// A JavaScript function is executed when "something" invokes it (calls it).

// examples of functions
// basic functions
// functions with parameters
// function expressions
// arrow functions
// function scopes
// anonymous functions
// nested functions
// immediately invoked functions

// functions without parametrs
// a function without a parameter is a function that  only it needs to be done is to execute the code inside it.

function sayhello(){
    console.log("hello wrld")
}
// call the function
sayhello()

function saygoodbye(){
    console.log("goodbye friend")
}
saygoodbye()

function saygoodmorning() {
    console.log("goodmorning dear")
}
saygoodmorning()

function mycountry() {
    console.log("It is named Kenya")
    console.log("It has many tourist attractions")
    console.log("It has a population of about 50 million")
    console.log("It is located in east africa")
    console.log("its main income is from tourism and agriculture")
}
mycountry()

