// Arrow functions without parameters
const greeting=()=>{
    console.log("hello wrld")
}
greeting()

const name=()=>{
    console.log("my name is josh")
}
name()

const add=()=>{
    num1=10
    num2=30
    sum=num1+num2
    console.log("the sum is", sum)
}
add()

