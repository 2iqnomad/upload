// the deference between let, const and var
// a let is a block-scoped meaning its only within the  block where its declared
// a var is function-scoped or globally-scoped,,,means if your data is a var inside a function it is throught the function
// const is a block-scoped and it is hoisted to the top of its block but canotbe accesed before its declarition due to "temperal dead zone"
let wheight = 80//declare a variable with let keyword
console.log(wheight)
const age = 20//declare a variable with const keyword
console.log(age)
//using let declare variables to store height, temperature, points
let height = 40
console.log(height)

let temperature = 37
console.log(temperature)

let points =57
console.log(points)