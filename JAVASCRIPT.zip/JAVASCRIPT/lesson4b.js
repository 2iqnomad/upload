// anonimous function
// this is a function without a name
// example;
const greeting=function(){
    console.log("welcome to world of great possibilities")
}
greeting()

// anonimous function to log my name
const myname=function(){
    console.log("my name is josh")
}
myname()

const mycounty=function(){
    console.log("my county is kiambu")
}
mycounty()

// anonimous function to log 5 messages about my country
const mycountry=function(){
    console.log("my country is kenya")
    console.log("it is in east africa")
    console.log("it has alot of willdlife")
    console.log("it has a population of about 50 milion")
    console.log("it recieves alot of tourist")
}
mycountry()