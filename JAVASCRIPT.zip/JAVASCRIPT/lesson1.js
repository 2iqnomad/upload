// java script ia a programming language used for web development

console.log("Hello world")
console.log("Goodmorning")
console.log("Goodevening")
console.log("Goodafternoon")