// Javascript for loops
// java script for loops are loops that loop through a sequence of code until the met requirement is executed
for(let i=0; i<=5;i++){console.log(i)}

// exaple 2

for(let i=0; i<=20;i++){console.log(i)}


// examle 4

for(let year=1900; year<=2000; year+=4){console.log(year)}

// example 3

for(let i=1; i>=10 ;i-=1){console.log(i)} 

// examle 5
for(let year=1967; year<=2030; year+=5){console.log(year)}

// examle 6

for(let year=1969; year<=2020; year+=10){console.log(year)}

// example 7

for(let year=2022; year>=1967; year-=5){console.log(year)}