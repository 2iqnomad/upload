// create a function called welcom and log the console 
// "hello wrld"

function welcome(){
    console.log("hello wrld")
}
welcome()

function welcome1(){
    console.log("welcome to our functions")
}
welcome1()

// using mpesa scenario:
// 1)create a function to send money
function sendmoney(){
    console.log("enter phone number of the recipent")
}
sendmoney()

// 2)function to withdraw cash
function withdraw(){
    console.log("how much do you wnt to withdraw")
}
withdraw()

// 3)function to buy airtime
function buyairtime(){
    console.log("ammount")
}
buyairtime()

// 4)function for loans and savings
function loansandsavings(){
    console.log("mshwari or KCB")
}
loansandsavings()

// 5)lipa na mpesa
function lipanampesa(){
    console.log("paybill ,buy goods and services or pochi la biashara")
}
lipanampesa()

// 6)my account
function myaccount(){
    console.log("account details")
}
myaccount()