// if statements
// if statement are programming constructs that allow you to make decisions based on condition
// executes only for the true conditions
let age=7
if (age<14){
    console.log("youre to young to watch this movie")
}