// create an array of 5 animals and log inn the console
let animals=["elephant","lion","zebra","wathog","cheater"]
console.log(animals)

// an array of 6 capital cities and log them in the console
let cities=["nairobi","kampala","darsalam","mogadishu","newyork"]
console.log(cities)

// create an array of 6 boks and log them in the console
let books=["book1","book2","book3","book4","book5"]
console.log(books)