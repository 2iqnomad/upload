# Create a function to calculate simple interest
def simple_interest():
    principal=200000
    rate=0.12
    time=3
    interest=principal*rate*time
    print("your interest for",time,"years is",interest)
simple_interest()

# Function to calculate BMI
def BMI():
    masss=70
    height=1.85
    bmi=masss/(height**2)
    print("your bmi is",bmi)
BMI()

# using functions with parameters calculate the area of a triangle
def area(base,height):
    answer=0.5*base*height
    print("The area of the triangle is",answer)
area(40,4)

# create a function to calculate the area of a circle
def area(radius):
    answer=(22/7)*(radius**2)
    print("The area is",answer)
area(7)

# calculate bmi using function with parameters
def BMI(mass,height):
    answer=mass/(height**2)
    print("Your bmi is",answer)
BMI(70,1.85)
