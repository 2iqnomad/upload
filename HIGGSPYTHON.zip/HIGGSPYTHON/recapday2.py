# list of 5 countries
countries=["Nigeria","Ghana","Algeria","Kenya","Rwanda"]
print(countries)
print(countries[2])
countries.append("Germany")
countries.insert(3,"Brazil")
print(countries)