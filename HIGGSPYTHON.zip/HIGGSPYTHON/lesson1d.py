# Arithmetic operators
# addition
number1=78
number2=12
sum=number1+number2
print("the sum of the two numbers is",sum)

# subtraction of two numbers
subtraction=number1-number2
print('the differenceof the two numbers is',subtraction)

# multiplication of two numbers
number1=5
number2=10
multiplication=number1*number2
print("the product of two numbers is",multiplication)

# division of two numbers
division=number2/number1
print("The quotient of the two numbers is",division)

# modulus of two numbers
number1=5
number2=2
modulus=number1%number2
print("the modulus is",modulus)

# exponent of two numbers
exponent=number1**number2
print("the exponent of the two numbers is",exponent)

# floor division of two numbers
number1=49
number2=2
floor_division=number1//number2
print("the floor division is",floor_division)

