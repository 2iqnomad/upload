# Boolean data type
# A boolean data can either be true or false
print(3>4)
print(5>4)

age=10
print(age<18)