# loop through 1 to 100
for number in range(1,101):
    print(number)

# loop through 200 to 400
for number in range(200,401):
    print(number)

# loop through 1 to 100 step 10
for number in range(1,101,10):
    print(number)

# loop through 200 to 400 step 6
for number in range(200,401,6):
    print(number)

# loop through a list of five students
students=["Kevin","Martin","Bob","Jeff","Mike"]
for student in students:
    print(student)

# loop through a list of 5 movies
Movies=["Jaws","Jaws 2","Killer bean","Chucky","Texas chainsaw masssacar"]
for movie in Movies:
    print(movie)

# loop through a list of 5 books
books=["Boy in striped pajamas","Book 2","book 3","book 4","book 5"]
for book in books:
    print(book)

# New year countdown
counter=60
while counter>=1:
    print(counter)
    counter=counter-1