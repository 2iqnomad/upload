# loop through a list using for loop
languages=["English","Japanese","Chinese","italian","French","Swahili","Arabic","German","Spanish"]


# loop Through languages
for language in languages:
    print(language)