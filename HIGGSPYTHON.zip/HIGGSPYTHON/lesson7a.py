# 1) What is a variable and give two examples
# a variable is a container used to store values in a python code
# add
# subtract

#2) Give four rules of naming variables
#a) cannot contain spaces 
#b) must start with a letter 
#c) special values use are the inderscore only
#d) must avoid using key words eg. if

#3) Give two examples of variables
#a) num1
#b) num2

#4) List five arithmetic operators in python
#  addition(+)
# subtraction(-)
# multiplication(*)
# division(/)
# Exponent(%)

#5) What are python data types and give two examples
# python data types are the form in which data takes in a python code
# they are used to define variables in appython code
# a)integers
# b)string
# c)float

#6) what is a string data type and give two examples
# it is a data type in which data is enclose in " " or ' 'inside brackets
# cars=("bmw","honda") 
# items=('cars','shoes')

#7) what are integer data types and give two examples
# it is a data type which contains whole numbers without decimal places
# num1=20
# num2=21

#8) What are float data type and give two examples
# they are data types that contain numbers with decimal places
# 21.35698
# 15.25

#9) What are boolean data types and give two examples
# they are data types display if a condition is true or false
# 2>1 true
# 2>5 False

#10) What are python lists and give an example of a list
# it is a group of values enclosed in brackets and within quotes and separated with a comma
# items=["car","shoes","houses"]
# print(items)

#11)  create a list of 56 countries
countries=["Kenya","Zambia","Djibouti","Rwanda","Egypt"]
print(countries)

#12) Create a list of five books
books=["river between","Adventure time","Diary of a wimpy kid","how to train your dragon","my life with a criminal"]
print(books)

#13)