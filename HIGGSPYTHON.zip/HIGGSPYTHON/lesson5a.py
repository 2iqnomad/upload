# Functions without parameters
def greeting():
    print("Hi")
    print("good morning")
# call
greeting()

# function to add two munbers
def add():
    num1=20
    num2=89
    answer=num1+num2
    print("The addition is",answer)
add()

#function of subtraction of two numbers
def subtract():
    num1=120
    num2=89
    answer=num1-num2
    print("The subtraction is",answer)
subtract()

#function of multiplication of two numbers
def multiply():
    num1=12
    num2=8
    answer=num1*num2
    print("The multiplication is",answer)
multiply()

#function of Division of two numbers
def divide():
    num1=80
    num2=16
    answer=num1/num2
    print("The division is",answer)
divide()

# area of a triangle
def area_of_a_triangle():
    base=20
    height=17
    area=0.5*base*height
    print("the area of the triangle is",area,)
area_of_a_triangle()

