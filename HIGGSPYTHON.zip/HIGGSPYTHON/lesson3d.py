# Calculating student marks
# We are going to include comparison and logical operators
# We want user to enter marks in terminal

Marks =55
if(Marks<30):
    print("Bellow average")
elif(Marks>=30 and Marks<40):
    print("Average")
elif(Marks>=40 and Marks<70):
    print("Above average")
else:
    print("Excelent")