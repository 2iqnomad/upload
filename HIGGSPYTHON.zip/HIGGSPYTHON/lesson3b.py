# if else statements
# It executes for true or false conditions 

number=-10
if(number>0):
    print("Positive number")
else:
    print("Negative number")
