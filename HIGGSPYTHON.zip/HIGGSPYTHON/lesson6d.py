# Python exeption handling
try:
    marks=10
    answer=marks/0
    print(answer)
except:
    print("Sthing went wrong")
    
    

