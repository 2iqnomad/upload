# Functions
# Function to visit a friend
def visitfriend():
    print("hello friend")

visitfriend()

# function eat lunch
def eating():
    print("I am eating")
eating()

# Function watch movie
def watch():
    print("I am watching a horror movie")
watch()

# function sleeping
def sleep():
    print("we are going to sleep")
sleep()

#  funcion to go home
def gohome():
    print("Goodbye im going home")
gohome()

# Function to take a shower
def showering():
    print("i am taking a shower")
showering()

# function cook supper
def cooking():
    print("i am cooking supper")
cooking()

# function attend Sarah's thanksgiving event
def attendevent():
    print("attend thanks giving event in the afternoon")
attendevent()

# function litsen to speech
def speech():
    print("litsen to speech")
speech()

# function interactions
def interactions():
    print("interact with people at the event")
interactions()

# function go home
def gohome():
    print("go home")
gohome()