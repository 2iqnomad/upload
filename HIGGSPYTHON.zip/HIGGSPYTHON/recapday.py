# interger
age=21
print(age)

mass=76
print(mass)

sttudents=40
print(sttudents)

workers=31
print(workers)

machines=45
print(machines)

# float
weight=20.5
print(weight)

mass=2.05
print(mass)

distance=100.87
print(distance)

height=1.95
print(height)

speed=90.5
print(speed)

# string
print("there are 20 cows")