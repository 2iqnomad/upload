counties=("embu","kajiado","nairobi","Nakuru","Bomet","Mombasa")
print(counties)

# accesss item at index 2
print(counties[2])

# print items from index 3 and above
print(counties[3:])

# print items up to index 4 and bellow
print(counties[:5])

# counties.append("Wajir")

# NB:It failed to append wajir county beacouse tuples cannot be changed