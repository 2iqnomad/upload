# python lists
items=["honda","nissan","surf","mazda","volkswagon"]
print(items)

# accesing items in a list
# we use index 
# NB: we start counting index from zero

# print item at index 2
print(items[2])

# adding items in the list
# 1.append method
# adds items to the end of the list
items.append("BMW")
print(items)

# 2.insert method
# add an item at a given index
items.insert(2,"toyota")
print(items)

# slicing
# we have the start index
# we have the stepsand end position/index

# print from index 3 and above
print(items[3:])

# print items upto index 4 and bellow
print(items[:5])
