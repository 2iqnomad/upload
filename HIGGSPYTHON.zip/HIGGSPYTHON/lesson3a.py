# If statements
# This works for one condition
# works only when true
age=27
if(age>=18):
    print("Adult")

number=-10
if(number>0):
    print("nnumber is positive")
    