# USing a for loop print from 2000 to 2024
for year in range(2000,2025):
    print(year)

# list of colors
colors=["blue","green","red","pink","black"]
for color in colors:
    print(color)

# using a while loop from 20 to 1
number=20
while number>=1:
    print(number)
    number=number-1


