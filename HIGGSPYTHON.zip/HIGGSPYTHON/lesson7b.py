# What is a function
# A function is a command that executes codes in python 

# Create a simple function called greetings and print hello wrld
def greetings():
    print("hello world")
greetings()

# Create a function to add two numbers

def add():
    num1=12
    num2=10
    sum=num1+num2
    print("the sum is",sum)
add()

# Create a function to subtract two numbers

def subtract():
    num1=12
    num2=10
    sub=num1-num2
    print("the diference is",sub)
subtract()

# create a function to find area of a circle
def area():
    radius=14
    area=(22/7)*(radius**2)
    print("The area is",area)
area()

# Create a function to calculate simple interest

def SI():
    amount=35000
    time=3
    int=12
    si=amount*(int/100)*time
    print("your iterest for",time,"years is",si)
SI()

# come up with a very simple if elif else for mpesa menu

option=7
if (option==1):
    print("send money")
elif (option<1):
    print("invalid option")
elif (option==2):
    print("Withdraw cash")
elif (option==3):
    print("Buy airtime")
elif (option==4):
    print("Loans and savings")
elif (option==5):
    print("Lipa na mpesa")
elif (option==6):
    print("my account")
elif (option==7):
    print("My account")
elif (option==8):
    print("Sim toolkit")
else:
    print("invalid option")