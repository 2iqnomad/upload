# integers
age=50
print(age)

# float
total=100.60
print(total)

# extra assignments
# more examples on integer data types
countries=54
print(countries)

students=21
print(students)

homes=100000
print(homes)

shops=300
print(shops)

workers=100
print(workers)

classes=10
print(classes)

# more examples on float data types
weight=50.5
print(weight)

liters=20.5
print(liters)

distance=12.6
print(distance)

height=1.92
print(height)

gallons=200.87
print(gallons)

storage=232.87
print(storage)