# Python dictionary
person={
    "first name":"John",
    "Last name":"Doe",
    "Age":25,
    "Favourite colors":["blue","green"],
    "Salary":5000
}
print(person)

# print the age
print(person["Age"])

# print first name
print(person["first name"])

# print salary
print(person["Salary"])

# updating the age to 34
person["Age"]=34
print(person)

# add new key value pair
person["Passport"]="boo780n"
print(person)

# Deleting item from dictionary
del person["Last name"]
print(person)