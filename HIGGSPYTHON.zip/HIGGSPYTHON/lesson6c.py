# buisd in functions
# python has build in functions
# we fave maths functions 
# we have statistic functionss
# lets look at maths functions
from math import sqrt, cos, pow
print(sqrt(100))
print(sqrt(25))
print(sqrt(81))
print (cos(45))
print(pow(10,2))
