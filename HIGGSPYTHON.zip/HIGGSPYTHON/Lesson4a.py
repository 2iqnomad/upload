# For loop
# A for loop is a loop that is used to iterate over a sequence and execute a block of code
# eg: 
for index in range(5,10):
    print(index) 