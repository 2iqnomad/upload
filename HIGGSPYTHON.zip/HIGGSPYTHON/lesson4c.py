# While loop
# A while loop is aloop that executes a set of statements as long as the specified condition is true

counter=1
while counter<=10:
    print(counter)
    counter=counter+1