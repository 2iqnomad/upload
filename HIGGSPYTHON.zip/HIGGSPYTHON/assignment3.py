amount=200
if(amount<0):
    print("Invalid ammount")
elif(amount>0 and amount<6000):
    print("150")
elif(amount>=6000 and amount<8000):
    print("300")
elif(amount>=8000 and amount<12000):
    print("400")
elif(amount>=12000 and amount<15000):
    print("500")
elif(amount>=15000 and amount<20000):
    print("600")
elif(amount>=20000 and amount<25000):
    print("750")
elif(amount>=25000 and amount<30000):
    print("850")
elif(amount>=30000 and amount<50000):
    print("1000")
elif(amount>=50000 and amount<100000):
    print("1500")
else:
    print("2000")







