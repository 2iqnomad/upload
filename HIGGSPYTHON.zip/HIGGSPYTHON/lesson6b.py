# we want to import lesson6a module
# we have two methods we can use

# METHOD 1
from lesson6a import add,subtract
# Add two numbers
add()

# function to subtract two numbers
subtract()

# METHOD 2
import lesson6a
# add two numbers
lesson6a.add()

# subtract two numbers
lesson6a.subtract()

# using metho number 1
# find  the area of triangle
# use module lesson 5a
from lesson5a import area_of_a_triangle
area_of_a_triangle()