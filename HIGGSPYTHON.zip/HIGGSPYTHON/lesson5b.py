# Functions with parameters
# a function with parameters are variables that are defined in the function definition
def greeting(name):
    print("hi")
    print("good morning",name)
greeting("Kevin")

# Adding two numbers
def add(num1,num2):
    answer=num1+num2
    print("The addition is",answer)
add(90,4)
add(500,100)
add(1000,800)

# Function to subtract two numbers
def subtract(num1,num2):
    answer=num1-num2
    print("The subtraction is",answer)
subtract(90,4)
subtract(658,158)

# functionto multiply two numbers
def multiply(num1,num2):
    answer=num1*num2
    print("The Multiplication is",answer)
multiply(11,7)
multiply(25,5)

# function to divide two numbers
def divide(num1,num2):
    answer=num1/num2
    print("The division is",answer)
divide(80,4)
divide(90,4)

