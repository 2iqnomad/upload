countries=["kenya","Tanzania","Uganda","Senegal","Malawi"]
for country in countries:
    print(country)

animals=["Monkey","cat","dog","lion","Hyena","Leopard","Chetah"]
for animal in animals:
    print(animal)