# python modules
# A python module is a file that contains python codes which include variables, functions and classes 
# A module can be imported
# Function to add two numbers
def add():
    num1=20
    num2=5
    sum=num1+num2
    print("The sum is",sum)
# add() 

# function to subtract two numbers

def subtract():
    num1=17
    num2=9
    subtract=num1-num2
    print("the subtraction is",subtract)
# subtract()    

