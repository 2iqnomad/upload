print("hello wrld!")
print("hello wrld")

