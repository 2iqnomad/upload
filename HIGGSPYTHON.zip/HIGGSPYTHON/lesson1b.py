# variables
# a variable is a container that holds the value
# Rules of naming variables
# must start with a letter or an underscore
# it is case sensitive
# it cannot start with a number
# reserved key words cannot be used as variables eg while, if, for, class
# cannot comtain special caracters
# variable names should be meaningfull

message1="this is a python string"
print(message1)
message2='this is also another string'
print(message2)